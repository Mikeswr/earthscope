Manual NASA POWER download and import

Use this route when scripts/fetch_power.py cannot run (for example no internet access in the environment).
You need five files, one per location, covering 1981 to 2025, with T2M, T2M_MAX, T2M_MIN, PRECTOTCORR, RH2M, WS10M and ALLSKY_SFC_SW_DWN.

Step 1. Download one file per location
Option A, the Data Access Viewer at https://power.larc.nasa.gov/data-access-viewer/ : choose the AG community, Monthly, a single point, enter the coordinates below, select the parameters, set 1981 to 2025 and download JSON (CSV also works). The files used so far had names like POWER_Point_Monthly_19810101_20251231_005d62N_000d17W_LST_Accra.json. The importer reads that name directly: location, coordinates, range and time standard.
Option B, the API: paste each URL into a browser address bar and save the JSON text with Ctrl+S, using the name under the URL.

Accra
https://power.larc.nasa.gov/api/temporal/monthly/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,WS10M,ALLSKY_SFC_SW_DWN&community=AG&longitude=-0.171&latitude=5.618&start=1981&end=2025&format=JSON
Save as: power_monthly_Accra_1981_2025.json

Kumasi
https://power.larc.nasa.gov/api/temporal/monthly/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,WS10M,ALLSKY_SFC_SW_DWN&community=AG&longitude=-1.616&latitude=6.695&start=1981&end=2025&format=JSON
Save as: power_monthly_Kumasi_1981_2025.json

Tamale
https://power.larc.nasa.gov/api/temporal/monthly/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,WS10M,ALLSKY_SFC_SW_DWN&community=AG&longitude=-0.843&latitude=9.408&start=1981&end=2025&format=JSON
Save as: power_monthly_Tamale_1981_2025.json

Wa
https://power.larc.nasa.gov/api/temporal/monthly/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,WS10M,ALLSKY_SFC_SW_DWN&community=AG&longitude=-2.503&latitude=10.063&start=1981&end=2025&format=JSON
Save as: power_monthly_Wa_1981_2025.json

Takoradi
https://power.larc.nasa.gov/api/temporal/monthly/point?parameters=T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,WS10M,ALLSKY_SFC_SW_DWN&community=AG&longitude=-1.76&latitude=4.9&start=1981&end=2025&format=JSON
Save as: power_monthly_Takoradi_1981_2025.json

If an API request fails: drop a parameter the message complains about, or replace end=2025 with end=2024. Do not edit anything inside the files.

Step 2. Validate before importing (nothing is changed)
    python scripts/validate_power_files.py path/to/folder
It checks each file and the files against each other, and writes reports/preimport_validation.json. Exit code 1 means a check failed; read the printed lines. To see a file's structure without data values, use python scripts/inspect_file.py <file>.

Step 3. Import
    python scripts/import_power.py path/to/folder
It identifies the location from the file name and cross checks it against the coordinates inside the file; it refuses on any disagreement. It reads units from each file's metadata and refuses missing or different units (only after you have confirmed the units yourself may you add --assume-documented-units). It refuses overlapping files that disagree on a month. It never fills in or replaces values. Imported copies go to data/raw under canonical names with a small .import.json record of the original file name and checksum.

Step 4. Analyse and report
    python scripts/run_analysis.py
    python scripts/make_figures.py
    python scripts/make_reports.py
    streamlit run earthscope/dashboard/app.py
run_analysis.py and make_reports.py refuse synthetic test data. Results go to reports/ (tables, figures and four markdown reports).

Before trusting any result
Open data/processed/power_monthly_metadata.json and check the source is NASA POWER (never SYNTHETIC TEST DATA), each variable's unit and unit_source, and actual_coverage against the years you asked for. NASA POWER values are gridded estimates, not station observations.
