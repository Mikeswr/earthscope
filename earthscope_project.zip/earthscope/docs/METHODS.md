EarthScope methods, thresholds and known limits

This file records what the code does, the minimum data each test needs, and what has and has not been verified. It was rewritten after the first real NASA POWER files were imported, and it corrects an earlier statement about T2M_MAX and T2M_MIN (section 1).

1. Data and what each variable means
NASA POWER values are gridded estimates built from reanalysis and satellite based sources. They are not direct station observations. Every row carries source, data_kind (gridded_estimate_not_station_observation), unit, unit_source and statistic.
The definitions come from the NASA POWER data processing page. Monthly values are the mean of the days and annual values the mean of the months, except for maximum and minimum parameters, which keep the value of the original instantaneous hourly time through the hierarchy. The average of the daily maximum is a different parameter (T2M_MAX_AVG) that is not in the files used so far.
T2M, RH2M, WS10M: monthly mean of daily means.
T2M_MAX: highest hourly value in the month (annual value: highest of the year).
T2M_MIN: lowest hourly value in the month (annual value: lowest of the year).
PRECTOTCORR: monthly mean of the daily precipitation rate in mm/day, not a monthly total.
ALLSKY_SFC_SW_DWN: monthly mean of the daily total, in kW-hr/m^2/day.
Correction: the first version of this file, and the code, described T2M_MAX and T2M_MIN as the monthly mean of daily maxima and minima. That was an assumption and it was wrong.
Checked against the five real files: annual T2M_MAX equals the maximum of the twelve monthly values and annual T2M_MIN the minimum in 45 of 45 years at all five locations; annual values of the mean parameters equal the day-weighted mean of the months to within rounding, and for T2M, RH2M, WS10M and PRECTOTCORR they differ from the simple mean by more than rounding; T2M_MAX >= T2M >= T2M_MIN in all months. This is consistent with the documentation but cannot prove how a monthly value was computed from hourly values; that needs daily or hourly data.
The response header lists the sources of the whole file (SYN1DEG, MERRA2, SRB, POWER) but not which source supplies which variable, and no spatial resolution per variable. The title says "Source Native Resolution". No resolution is assigned to any variable.

2. Units
Units are read from the response metadata for each parameter, accepted only if they equal the expected unit (C, mm/day, %, m/s, kW-hr/m^2/day) after spelling normalisation, and never converted silently. A missing unit stops processing unless --assume-documented-units is passed; those rows are then marked unit_source = assumed_documented_default. Kelvin, monthly totals and any unrecognised unit are rejected.

3. Quality control
Values are flagged missing or out_of_range and never altered. Flagged values are excluded from every trend, anomaly and annual statistic but stay in the data. Further diagnostics (scripts/run_analysis.py): months with |z| >= 3 against the calendar-month climatology, runs of identical values, and the Pettitt change point test (section 11). These flag items for a person to check and change nothing.

4. Provenance recorded in data/processed/power_monthly_metadata.json
For each raw file: name, bytes, SHA-256, the response header and per-parameter metadata copied verbatim, header sources, time standard (LST means local solar time), requested start and end, the import record (original file name, original checksum, how the location was identified), the request URL and retrieval time when the file came from fetch_power.py, and the actual coverage per variable (first and last month present, first and last valid month, months present, missing values, months absent inside the span).
scripts/validate_power_files.py checks files before import: JSON validity and duplicate keys, POWER structure, requested against returned parameters, units, key sets and the returned range against the header, annual keys, coordinates and location identity (file name against file content against configured points), physical limits, and the interpretation evidence in section 1.

5. Calendar integrity
Missing and flagged observations keep their calendar position as NaN. monthly_series returns the complete monthly index from the first to the last date present, whatever the QC flag, so a flagged first, middle or last year is never deleted and the range never shrinks. The anomaly table keeps every month with a qc_flag column that says why a value is empty. Coverage rules measure the nominal span of the record, including NaN years at the start, middle and end: a series with 15 flagged leading years out of 45 has 67 percent coverage, not 100 percent. Callers that pass the engine a series with the gaps already removed get the span of what they passed, which is documented behaviour.
This was found by auditing every function that handles calendar positions after a flagged-first-year defect was reported. Four places had the problem: monthly_series, the annual and seasonal span calculation in the engine, and the anomaly table. Regression tests cover a flagged first, last and middle year and the coverage rule.

6. Annual series
Mean variables: the mean of the 12 monthly values weighted by days in each month. T2M_MAX: the annual maximum of the monthly values. T2M_MIN: the annual minimum. A year needs all 12 valid months. Years that fail stay in the series as NaN and the engine uses real year labels.

7. Minimum data per test
Annual Mann-Kendall and Sen's slope: at least 10 valid years and valid years covering at least 70 percent of the nominal span.
Seasonal Mann-Kendall: every calendar month needs at least 10 valid years covering at least 70 percent of the nominal span.
Anomalies: each calendar month needs at least 20 valid values inside the 1991 to 2020 base period.
A series that does not qualify is reported as insufficient_data with the reason in mk_reason or seasonal_reason, never a number. These thresholds are my choices, not published standards. They are constants at the top of earthscope/trends/engine.py.

8. Temporal integrity of the estimators
Sen's slope is the median of (x_j - x_i) / (year_j - year_i) over all pairs, so missing years do not compress time. Its confidence interval uses Var(S), inflated for autocorrelation, and interpolates between the ranked pairwise slopes; against scipy.stats.theilslopes it agrees to 0.002 in a test, and its coverage was 92 to 98.5 percent in a 400 run check with independent noise.
The seasonal test works month by month: S and Var(S) within each calendar month across years, then added. It treats months as independent, so its p value is optimistic when neighbouring months are correlated. In the real data it gives p values near zero where the annual test finds nothing. It is kept in the tables and never used for a significance statement. A covariance corrected seasonal test is not implemented.

9. Autocorrelation (annual test)
Options: ar1_neff (default), hamed_rao, none. ar1_neff inflates Var(S) from the lag-1 autocorrelation of the Sen-detrended series, never below 1. hamed_rao is the Hamed and Rao (1998) correction, which reproduces pymannkendall exactly on complete data.
Simulation: 400 series of length 40, no trend, AR(1) noise, nominal rate 0.05, simulation noise about 1 percentage point. Exploratory run, false positive rate at phi 0, 0.3, 0.6: none 0.045, 0.110, 0.270; Hamed-Rao 0.070, 0.125, 0.200; ar1_neff 0.043, 0.060, 0.070; trend-free pre-whitening 0.050, 0.142, 0.360; a simple block bootstrap 0.105, 0.107, 0.138. Through the shipped engine with another random draw: none 0.050, 0.135, 0.273; Hamed-Rao 0.068, 0.155, 0.200; ar1_neff 0.035, 0.070, 0.095. Power at a true trend of 0.04 per year and phi 0.3: about 0.68 uncorrected, 0.52 with ar1_neff.
The correction brings the error rate much closer to nominal but is not exact at strong autocorrelation, and it costs power. The simulations used AR(1) noise, which favours an AR(1) based correction, and only n = 40.
Hamed-Rao can return a zero or negative corrected variance. That now comes back as an explicit insufficient result and never as p = 1. Observed in 400 series of length 40: 4 at phi 0, 5 at phi 0.3, 1 at phi 0.6 and 94 at phi -0.5. ar1_neff cannot do this.

10. Multiple testing and evidence classes
FDR is Benjamini-Hochberg by default and Benjamini-Yekutieli as an option, applied within pre-declared families: the six meteorological variables at all locations form the primary family and ALLSKY_SFC_SW_DWN is a secondary family because it blends sources over time. Output carries p (uncorrected), p_fdr, significant_uncorrected and significant_fdr, and one evidence_class per series: significant_after_fdr, significant_before_fdr_only, not_significant or insufficient_data. The descriptive Sen slope is always present; only significant_after_fdr is treated as a finding.
BH is valid under independence and positive dependence. Variables at one location and neighbouring locations are correlated, so FDR here is approximate. The field significance literature (for example Wilks 2016, Bulletin of the American Meteorological Society) discusses FDR for spatially correlated fields; I have not re-read it for this project, so check it before citing.

11. Homogeneity
The Pettitt test is run on each annual series, raw and after removing the Sen trend. The raw test also fires on a steady trend, so only a hit after detrending points to a step or non-linear change. It assumes independent years and has limited power; a hit is a flag, a non-hit is not proof of homogeneity.

12. Spatial analysis
grid_trends needs a gridded annual field with an explicit integer year coordinate and uses the real years in every cell. The five city points cannot support a spatial field, so the dashboard map shows point results only and nothing is interpolated between them.

13. What is verified
The statistics match pymannkendall and scipy on complete data to 1e-9 or better, small cases match hand calculation, unequal spacing matches scipy.stats.theilslopes, the FDR code matches a hand written Benjamini-Hochberg, and the real import was checked value by value against the raw files (18,900 values, no mismatch) and by checksum against the upload. I also reintroduced original defects one at a time into a scratch copy and confirmed the suite fails each time: the seasonal reshape, Sen's slope on index steps, FDR removed from the grid, FDR removed from the trend table, a silent unit fallback, a key leaking into an error, a monthly series that drops flagged rows, and span measured from the first valid year (annual and seasonal) or an anomaly table that drops NaN months. That process found a hole in the first version of the FDR tests, which is now covered.
What is not verified: behaviour against live OpenWeather or Agromonitoring responses, and any agreement of NASA POWER values with station records.

14. External APIs
See docs/CREDENTIALS.md. The clients are written from the vendors' documentation, are marked unverified in code, and nothing in the reports uses them.
