Credentials and API access

Variable names
OPENWEATHER_API_KEY
AGROMONITORING_API_KEY
No other names are read.

Where to put them
Local machine: copy .env.example to .env and fill it in. .env is ignored by git.
Terminal session: export OPENWEATHER_API_KEY=... and export AGROMONITORING_API_KEY=...
Streamlit deployment: put the same two names in .streamlit/secrets.toml (ignored by git) or in the hosting service's secrets settings, as OPENWEATHER_API_KEY = "..." lines.
Lookup order is the environment first, then .streamlit/secrets.toml.
Never paste a key into a chat, an issue, a notebook or a commit. If one has been shared anywhere, revoke it in the provider's account page and create a new one.

Why redaction matters
Both services take the key as a query parameter, so it sits in the request URL. Error messages from the HTTP library include that URL. The code redacts the key from every error and raises without chaining the original exception, and the tests check that the key is absent from both the message and the traceback. Do not turn on verbose HTTP logging while a key is in use.

Testing your access
python scripts/check_apis.py
python scripts/check_apis.py --create-polygon   (creates a small test polygon if your Agromonitoring account has none)
python scripts/check_apis.py --save-samples      (also saves the raw responses to data/raw/api_samples)
The script calls each endpoint once, writes data/processed/api_probe_report.json (no keys in it) and prints one line per endpoint. An endpoint counts as working only if the call returned HTTP 200 and the response had the fields the parser needs.
How to read a failure: 401 means the key was rejected or is not active yet. 403 means the key is valid but that endpoint is not in your plan. 429 means a rate limit or quota. Status None means the host could not be reached.

What each endpoint needs (from the vendors' documentation, not confirmed for your key)
OpenWeather current weather, data/2.5/weather: available on the free plan.
OpenWeather day summary, data/3.0/onecall/day_summary: part of One Call API 3.0, which the documentation ties to a One Call by Call subscription. Daily aggregates are documented from 1979 onward.
OpenWeather hourly history, history.openweathermap.org: documented as depending on subscription, with Professional and Expert plans named.
Agromonitoring weather history: hourly archive, depth depends on the plan.
Agromonitoring NDVI history: needs a polygon (area between 1 and 3000 hectares). The satellite archive is documented as starting in 2018, with an older archive on a higher plan.
The keys from the Space Apps Challenge may cover only some of these. The probe tells you which.

Status
Both clients are marked VERIFIED_AGAINST_LIVE_API = False in code. Change that only after the probe has reported OK for the endpoints you rely on.
